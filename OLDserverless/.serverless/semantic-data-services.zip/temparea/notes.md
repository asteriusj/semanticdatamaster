

# Test with $ serverless invoke local -f jsonschema2formfield -p data.json --log

# Deploy to AWS with $ serverless deploy --aws-profile default

